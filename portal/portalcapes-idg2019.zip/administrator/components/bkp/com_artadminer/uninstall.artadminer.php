<?php
/**
* @module		Art Adminer
* @copyright	Copyright (C) 2013 artetics.com
* @license		GPL
*/
defined('_JEXEC') or die('Direct Access to this location is not allowed.'); 

function com_uninstall()
{
	global $installer;
	
	return true;
}

?>
